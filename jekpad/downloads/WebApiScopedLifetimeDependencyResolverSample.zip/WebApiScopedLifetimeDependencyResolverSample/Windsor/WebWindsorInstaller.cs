﻿using System.Web.Http.Controllers;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.SubSystems.Configuration;
using Castle.Windsor;
using WebApiScopedLifetimeDependencyResolverSample.Controllers;
using WebApiScopedLifetimeDependencyResolverSample.Models;

namespace WebApiScopedLifetimeDependencyResolverSample.Windsor
{
    internal class WebWindsorInstaller : IWindsorInstaller
    {
        public void Install(IWindsorContainer container, IConfigurationStore store)
        {
            container.Register(Component
                .For<IValuesRepository>()
                .ImplementedBy<DefaultValuesRepository>()
                .LifestyleScoped());

            container.Register(Classes
                .FromAssemblyContaining<ValuesController>()
                .BasedOn<IHttpController>()
                .LifestyleScoped());
        }
    }
}