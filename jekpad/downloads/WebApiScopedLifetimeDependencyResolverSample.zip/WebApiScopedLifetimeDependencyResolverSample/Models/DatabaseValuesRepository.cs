﻿using System;
using System.Collections.Generic;

namespace WebApiScopedLifetimeDependencyResolverSample.Models
{
    public class DatabaseValuesRepository : IValuesRepository
    {
        public IEnumerable<int> GetAllValues()
        {
            throw new NotImplementedException();
        }

        public int GetValue(int id)
        {
            throw new NotImplementedException();
        }
    }
}