﻿using System.Collections.Generic;

namespace WebApiScopedLifetimeDependencyResolverSample.Models
{
    public interface IValuesRepository
    {
        IEnumerable<int> GetAllValues();

        int GetValue(int id);
    }
}