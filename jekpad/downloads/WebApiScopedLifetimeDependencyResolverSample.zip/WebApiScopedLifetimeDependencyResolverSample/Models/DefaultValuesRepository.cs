﻿using System.Collections.Generic;

namespace WebApiScopedLifetimeDependencyResolverSample.Models
{
    public class DefaultValuesRepository : IValuesRepository
    {
        public IEnumerable<int> GetAllValues()
        {
            return new int[] { 1, 2 };
        }

        public int GetValue(int id)
        {
            return id;
        }
    }
}