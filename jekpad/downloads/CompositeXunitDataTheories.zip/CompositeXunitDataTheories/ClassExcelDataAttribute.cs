﻿using System;
using Ploeh.AutoFixture.Xunit;
using Xunit.Extensions;

namespace CompositeXunitDataTheories
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    internal sealed class ClassExcelDataAttribute : CompositeDataAttribute
    {
        internal ClassExcelDataAttribute(Type type, string filename, string selectStatement)
            : base(new DataAttribute[] { 
                new ClassDataAttribute(type), 
                new ExcelDataAttribute(filename, selectStatement) })
        {
        }
    }
}
