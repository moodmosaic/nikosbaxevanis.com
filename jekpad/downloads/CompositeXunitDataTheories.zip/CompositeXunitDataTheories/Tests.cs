using System;
using System.Collections;
using System.Collections.Generic;
using Xunit.Extensions;

namespace CompositeXunitDataTheories
{
    public sealed class Tests
    {
        [Theory]
        [ExcelData("UnitTestData.xls", "SELECT x, y FROM Data")]
        public void Foo(object x, object y)
        {
            Console.WriteLine("{0}, {1}", x, y);
        }

        [Theory]
        [ClassExcelData(
            typeof(CollectionOfSpecifiedString),
            "UnitTestData.xls", "SELECT x, y FROM Data")]
        public void Zoo(object x, object y)
        {
            Console.WriteLine("{0}, {1}", x, y);
        }

        private sealed class CollectionOfSpecifiedString : IEnumerable<object[]>
        {
            public IEnumerator<object[]> GetEnumerator()
            {
                yield return new object[] { "zoo" };
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this.GetEnumerator();
            }
        }
    }
}